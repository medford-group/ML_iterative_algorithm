# -*- coding: utf-8 -*-
"""
Created on Sun May 27 13:42:57 2018

@author: fuzhu
"""


data = 'mixed_data_all.csv'
#data = 'mixed_data_all_with_bad_data.csv'
band_width = 20  # 20  #### 14 <= sigma <=20 

from extractDos import Extract
E = Extract()
index = {
        'top_metal':42,
        'top_metal_vac':18,
        'top_other':45,
        'bridge':[43,19],
        '3fold':None,
        '4fold':None}

df = E.AtomDOS(data,n_left=300,n_right=1500,index=index,band_width=band_width) # n_left=300   n_right=1500

"""
import shutil
destination_path = '/home/fuzhu/Documents/PCA/rutile_TiO2/PLS/mixed_flat_movement/Gene_Data/gpr_fs_fs/New_descriptor_Alldata/Model_Adsorption_Energy'
dos = 'dDOS_smooth.csv'
shutil.copy(dos,destination_path)

dos_e = 'dos_e.csv'
shutil.copy(dos_e,destination_path)
print ('Done')

"""


"""
from CoulombMatrix_fingerprint_Mol import Fingerprint
F = Fingerprint()
CM_fpts, sinCM_fpts = F.adsorbateFigerprint(data,Max_atom_number=4,permutation='eigenspectrum')

import shutil
destination_path = '/home/fuzhu/Documents/PCA/rutile_TiO2/PLS/mixed_flat_movement/Gene_Data/gpr_fs_fs/New_descriptor_Alldata/Model_Adsorption_Energy'
fpts = 'sinCM_fpts.csv'
shutil.copy(fpts,destination_path)
fpts_CM = 'CM_fpts.csv'
shutil.copy(fpts_CM,destination_path)
print ('Done')
"""

