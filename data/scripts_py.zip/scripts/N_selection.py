# -*- coding: utf-8 -*-
"""
Created on Tue Dec  4 08:57:13 2018

@author: fuzhu
"""


import pandas as pd
from itertools import combinations, product
from random import sample
import sys
sys.setrecursionlimit(100000)

class N_square_Selection():
    
    def NewDataSet_Index(self,AdsSiteSlab_data,N,threshold=200):
        df_AdsSiteSlab = N_square_Selection.read_data(self,AdsSiteSlab_data)
        df_AdsSiteSlab_List = df_AdsSiteSlab.values.tolist()
        
        Adsorbates = N_square_Selection.Ads(self)
        combs = N_square_Selection.N_adsorbates(self,Adsorbates,N,threshold)
        
        Index = []
        Len_lowcoverage = []
        for comb in combs:
            index = []
            for ads in comb:
                for list_i in df_AdsSiteSlab_List:
                    ads1, ads2 = list_i[0], list_i[2]
                    if ads1 == ads and ads2 == 'None':
                        indx = df_AdsSiteSlab_List.index(list_i)
                        index.append(indx)
            Len_lowcoverage.append(len(index))

            ads_pairs = N_square_Selection.Nselect2(self,comb)
            for ads_pair in ads_pairs:
                for list_i in df_AdsSiteSlab_List:
                    ads1, ads2 = list_i[0], list_i[2]
                    site2 = list_i[3]
                    if (ads1 == ads_pair[0]) and (site2 == 'top_other'):
                        continue
                    if (ads1 == ads_pair[0]) and (ads2 == ads_pair[1]):
                        indx = df_AdsSiteSlab_List.index(list_i)
                        index.append(indx)
            Index.append(index)
                        
        Len_highcoverage = []
        for index in Index:
            Transition_ASS = [df_AdsSiteSlab_List[i] for i in index]
            repeat_highcover_index = []
            for state in Transition_ASS:
                ads1, site1 = state[0], state[1]
                ads2, site2 = state[2], state[3]
                for list_i in Transition_ASS:
                    if (ads2 == list_i[0]) and (site2 == list_i[1]) and (ads1 == list_i[2]) and (site1 == list_i[3]):
                        ind = Transition_ASS.index(list_i)
                        repeat_highcover_index.append(ind)
            len_highcoverage = len(index) - len(repeat_highcover_index)/2
            Len_highcoverage.append(len_highcoverage)

        
        print ('N = %s' % N)
        print ('Number of LC structures = %s' % Len_lowcoverage)
        print ('Number of HC structures = %s' % Len_highcoverage)
        return Index, Len_lowcoverage, Len_highcoverage
                
    def Nselect2(self,comb):
        ads_pairs = product(comb,repeat=2)
        return ads_pairs
    def N_adsorbates(self,Adsorbates,N,threshold):
        combs = combinations(Adsorbates,N)
        Combs = list(combs)
        print (len(Combs))
        if len(Combs) > threshold:
            combs = sample(Combs,threshold)
        else:
            combs = Combs
        return combs
    def Ads(self):
        Adsorbates = ['H','H2O','O','OH','C','CH','CO','CH2','CH3','N','NO','NH','NH2','NH3']
        #Adsorbates = ['H','H2O','CH','CH2','CH3','CO','NO','NH','NH2','NH3']
        return Adsorbates
    def read_data(self,AdsSiteSlab_data):
        df_AdsSiteSlab = pd.read_csv(AdsSiteSlab_data)
        df_AdsSiteSlab = df_AdsSiteSlab.dropna(axis=0,how='any')
        return df_AdsSiteSlab
    
