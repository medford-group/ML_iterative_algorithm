# -*- coding: utf-8 -*-
"""
Created on Fri Feb  8 11:55:58 2019

@author: fuzhu
"""

#  only do pca for DOS

#  extract features from raw data
dos_data = 'New_dDOS_smooth.csv'
#ads_fpt_data = 'self_Afpt.csv' #'custom_CM_fpts.csv' # CM_fpts.csv
ads_fpt_data = 'New_custom_CM_fpts.csv' #'custom_CM_fpts.csv' # CM_fpts.csv
energy_file = 'New_mixed_data_corr.csv' 
origin_data = 'New_for_formation_AdsSlabSite_corr.csv'

# #######  drop the empty observations
# then do pca
import pandas as pd
df1 = pd.read_csv(dos_data)
df2 = pd.read_csv(ads_fpt_data)
df3 = pd.read_csv(energy_file)
df4 = pd.read_csv(origin_data)


Gf = df3['Gf']
#print (Gf)
Index = []
for k, gf in enumerate(Gf):
    if gf > -100:
        Index.append(k)
#print (len(Index))
columns_1 = df1.columns.get_values().tolist()
Values_1 = df1.values.tolist()   # pd.values()   == pd.to_numpy()
Values_dropna = [Values_1[k] for k in Index]
ddf_1 = pd.DataFrame(Values_dropna,columns=columns_1) # 
ddf_1.to_csv('DOS_X.csv',index=False)  # svae the DOS
print (ddf_1.shape)

#from sklearn.preprocessing import StandardScaler, MinMaxScaler

columns_2 = df2.columns.get_values().tolist()
Values_2 = df2.values.tolist()
Values_dropna = [Values_2[k] for k in Index]

#scaler = MinMaxScaler()
#XXX = scaler.fit_transform(Values_dropna)
#ddf_2 = pd.DataFrame(XXX,columns=columns_2)

ddf_2 = pd.DataFrame(Values_dropna,columns=columns_2)
ddf_2.to_csv('CM_X.csv',index=False)  # save CM
print (ddf_2.shape)

columns_3 = df3.columns.get_values().tolist()
Values_3 = df3.values.tolist()
Values_dropna = [Values_3[k] for k in Index]
ddf_3 = pd.DataFrame(Values_dropna,columns=columns_3)
ddf_3.to_csv('enery_X.csv',index=False)  # save CM
print (ddf_3.shape)


columns_4 = df4.columns.get_values().tolist()
Values_4 = df4.values.tolist()
Values_dropna = [Values_4[k] for k in Index]
ddf_4 = pd.DataFrame(Values_dropna,columns=columns_4)
ddf_4.to_csv('formation_ASS_X.csv',index=False)  # save CM
print (ddf_4.shape)
#########


dos_data = 'DOS_X.csv'
ads_fpt_data = 'CM_X.csv' # CM_fpts.csv
energy_file = 'enery_X.csv' 

        
df = pd.read_csv(dos_data)
CM_X = pd.read_csv(ads_fpt_data)
columns1 = CM_X.shape[1]
energy = pd.read_csv(energy_file)
Ead = energy[list(energy.columns)[-1]]

from DO_PCA import pca

n_components = 2

DOS_X = pca(df=df,n_components=n_components,standardscaler=False)
New_features = pd.concat([CM_X,DOS_X],axis=1)

from sklearn.preprocessing import StandardScaler   ######
columns = New_features.columns
#New_features = pd.DataFrame(StandardScaler().fit_transform(New_features),columns=columns)

New_features.insert(loc=columns1+n_components,column='Ead',value=Ead)
New_features.to_csv('New_features_Ead.csv',index=False)

from Iteration import iteration
I = iteration()
origin_data = 'formation_ASS_X.csv'
new_data = 'New_features_Ead.csv' #
i, MaxdE_testset, MAE_trainingset, MAE_testset, std_Tr, Num_outliers_percent = I.analyze_data(origin_data,new_data,Num=37,sigma_f=1,alpha=0.07,length_scale=10,max_cycle=200,
                                                                                              std=True,random_state=False,threshold_std=0.35,threshold_dE=1,kk=1)
print ("########iteration#######", i)
print ("MAE_test : %s" % MAE_testset)
