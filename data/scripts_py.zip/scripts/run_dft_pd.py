# -*- coding: utf-8 -*-
"""
Created on Thu Jan 10 12:48:54 2019

@author: fuzhu
"""


import pandas as pd
from DFT_Phase_Diagram import Run_phase_diagram

data_ASS = 'formation_ASS_X.csv'

# pre-processing
df = pd.read_csv(data_ASS)
columns = df.columns.tolist()
print (columns)
Ele = df.values.tolist()
index = []
for ele in Ele:
    site2 = ele[3]
    if site2 == 'top_other':
        ind = Ele.index(ele)
        index.append(ind)
#print (index)       
df.drop(index=index)
df.to_csv('A.csv',index=False)
data_ASS = 'A.csv'

#atomType_chemPot = {'H':[-2,2],'C':[0,4],'N':[-2,2],'O':[-2,2]}  # 4d
#atomType_chemPot = {'H':[-2,2],'C':[0,4],'N':[-2,2]}     # 3d
#ref_atomType_chemPot = {'O':2}  # 3d
####  [[['H','O'],['H','N']],[['O','N'],['H','C']],[['O','C'],['N','C']]]
#atomType_chemPot = {'O':[-14,6],'N':[-8,3]}   # 2d

pairs = [['H','O'],['H','N'],['O','N'],['H','C'],['O','C'],['N','C']]

##
ele_pair = ['O','N']   # 2d

if ele_pair == ['H','O']:
    atomType_chemPot = {'H':[-3,2],'O':[-1,5]}
    ref_atomType_chemPot = {'N':-0.0025, 'C':-3.103240777568283}
if ele_pair == ['H','N']:
    atomType_chemPot = {'H':[-3,2],'N':[-2,4]}
    ref_atomType_chemPot = {'O':2.17288548257862/2, 'C':-3.103240777568283}
if ele_pair == ['O','N']:
    atomType_chemPot = {'O':[-1,5],'N':[-2,4]}
    ref_atomType_chemPot = {'H':-1.0664427412893163*2, 'C':-3.103240777568283}
if ele_pair == ['H','C']:
    atomType_chemPot = {'H':[-3,2],'C':[-6,8]}
    ref_atomType_chemPot = {'N':-0.0025, 'O':2.17288548257862/2}
if ele_pair == ['O','C']:
    atomType_chemPot = {'O':[-1,5],'C':[-6,8]}
    ref_atomType_chemPot = {'H':-1.0664427412893163*2, 'N':-0.0025}
if ele_pair == ['N','C']:
    atomType_chemPot = {'N':[-2,4],'C':[-6,8]}
    ref_atomType_chemPot = {'H':-1.0664427412893163, 'O':2.17288548257862/2}
    
N_int = 300

#atomType_chemPot = {'C':[-2,2]}   # 1d
#N_int = 200

rPD = Run_phase_diagram(data_ASS=data_ASS,atomType_chemPot=atomType_chemPot,
                        ref_atomType_chemPot=ref_atomType_chemPot,N_int=N_int,initial_training_number=43)
if len(atomType_chemPot) == 1:
    rPD.run_1d()
if len(atomType_chemPot) == 2:
    rPD.run_2d()
if len(atomType_chemPot) == 3:
    rPD.run_3d()
if len(atomType_chemPot) == 4:
    rPD.run_4d()

from Label_Encode_DFT import Run_Label_Encode
#atomType_chemPot = {'H':[-2,2],'C':[0,4]}   # 2d
#atomType_chemPot = {'H':[-2,2],'C':[0,4],'N':[-2,2],'O':[-2,2]}  # 4d
#atomType_chemPot = {'H':[-2,2],'C':[0,4],'N':[-2,2]}     # 3d
#N_int = 10
rLE = Run_Label_Encode(atomType_chemPot=atomType_chemPot,N_int=N_int)
XY, label_matrix = rLE.run_data_encode()
#rLE.plot_1d_pd(label_matrix)
#rLE.plot_2d_pd(label_matrix)
#rLE.plot_3d_pd_mlab(label_matrix)

"""
from mayavi import mlab
#mlab.contour3d(label_matrix)
#mlab.pipeline.volume(mlab.pipeline.scalar_field(label_matrix))
mlab.pipeline.image_plane_widget(mlab.pipeline.scalar_field(label_matrix),plane_orientation='x_axes',slice_index=0,)
#mlab.volume_slice(label_matrix,plane_orientation='x_axes',slice_index=0)
mlab.outline()
mlab.show()
"""
