#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 16 17:27:46 2020

@author: fuzhu
"""

import pandas as pd
import numpy as np
def get_string(df,label):
    Ads1 = df['Ads1'].tolist()
    Site1 = df['Site1'].tolist()
    Slab = df['Slab'].tolist()
    E_DFT_corr = df[label].tolist()###

    String = []
    E_x_dft = []

    for i in range(37):
        """ Eads(B) """
        string = Ads1[i] + '_' + Site1[i] + '_' + Slab[i]
        e_dft = E_DFT_corr[i]
        String.append(string)
        E_x_dft.append(e_dft)
    return String,E_x_dft
    
def get_corrections(df,String,E_x_dft):
    ads_strings = ['H','O','OH','H2','O2','H2O','C','CO','CH','CH2','CH3','CH4','N','N2','NO','NH','NH2','NH3']
    Ads2 = df['Ads2'].tolist()
    Site2 = df['Site2'].tolist()
    Slab = df['Slab'].tolist()
    E_corr_dft = []
    for k in range(len(Ads2)):
        ads2 = Ads2[k]
        site2 = Site2[k]
        slab = Slab[k]
        string = ads2 + '_' + site2 + '_' + slab
        #print (string)            
        if ads2 not in ads_strings:
            e_corr = 0
            E_corr_dft.append(e_corr)
        else:
            if string in String:
                idx = String.index(string)
                
                e_corr_dft = E_x_dft[idx]
                E_corr_dft.append(e_corr_dft)
            else:
                e_corr = 100 + k
                E_corr_dft.append(e_corr)
    return E_corr_dft

def Eint(df,label):
    Gf = df[label].tolist()
    String,E_x_dft = get_string(df,label)
    E_corr_dft = get_corrections(df,String,E_x_dft)
    Ef = []  ### here the Ef = EA + E(A|B)
    for k in range(len(Gf)):
        ef = Gf[k] + E_corr_dft[k]
        Ef.append(ef)
    Ef = Ef[37:]
    return Ef

def noEint(df,label):
    # label = Gf
    Gf = df[label].tolist()
    Ads1 = df['Ads1'].tolist()
    Site1 = df['Site1'].tolist()
    Ads2 = df['Ads2'].tolist()
    Site2 = df['Site2'].tolist()
    Slab = df['Slab'].tolist()
    S = []
    E = []
    for k in range(37):
        s = Ads1[k] + '_' + Site1[k] + '_None' + '_' + Slab[k]
        e = Gf[k]
        S.append(s)
        E.append(e)
    Ref = dict(zip(S,E))
    keys = list(Ref.keys())
    Ef = []
    
    for k in range(37,len(Gf)):
        s1 = Ads1[k] + '_' + Site1[k] + '_None' + '_' + Slab[k]
        s2 = Ads2[k] + '_' + Site2[k] + '_None' + '_' + Slab[k]
        if s1 not in keys or s2 not in keys:
            ef = 100 + k
            Ef.append(ef)
        else:
            ef = Ref[s1] + Ref[s2]
            Ef.append(ef)
    return Ef
       


df_train = pd.read_csv('best_trainingset.csv')
df_test = pd.read_csv('best_testset.csv')
columns = df_train.columns.get_values().tolist()
df = df_train.values.tolist() + df_test.values.tolist()
dff = pd.DataFrame(df,columns=columns)
print (dff.shape)
Ef_1 = Eint(dff,label='Eml')
Ef_2 = noEint(dff,label='Eml')
print (len(Ef_1),len(Ef_2))

diff1 = []  ### ML
for k in range(len(Ef_1)):
    d = Ef_1[k] - Ef_2[k]
    diff1.append(d)
    
Ef_3 = Eint(dff,label='Ead')
Ef_4 = noEint(dff,label='Ead')

diff2 = []  ## DFT
for k in range(len(Ef_3)):
    d = Ef_3[k] - Ef_4[k]
    diff2.append(d)

###
#recorde the structures with larger interaction energies
LIS = []
ddf = df[37:]
for k, x in enumerate(diff2):
    if x > 1:
        stru = ddf[k]
        stru.append(x)
        LIS.append(stru)
print (len(LIS))
col = list(columns) + ['Eint']
data = pd.DataFrame(LIS,columns=col)
data.to_csv('structures_with_large_interactions.csv',index=False)
###


#--------------
indexs1 = []
Diff1 = []   ###  
for k, diff in enumerate(diff1):
    if diff > -10:
        indexs1.append(k)
        Diff1.append(diff)
Diff2 = []        # DFT interactions
for k in indexs1:
    Diff2.append(diff2[k])


#------------------
diff = np.array(Diff2) - np.array(Diff1) ## dft - ml
abs_deltaE = [abs(i) for i in diff]
MAE_int = sum(abs_deltaE)/len(diff)

import matplotlib.pyplot as plt

"""
fig, ax = plt.subplots(figsize=(5,5))
ax.scatter(Diff2,Diff1)
xmin, xmax = plt.xlim()
t = np.linspace(xmin-1,xmax+1,30)
y = t
ax.plot(t,y,'--',color='k')
ax.set_xlim(xmin,xmax)
ax.set_ylim(xmin,xmax)
ax.set_xlabel('E$_{DFT}^{int}$ (eV)', fontsize=20)
ax.set_ylabel('E$_{ML}^{int}$ (eV)', fontsize=20)
ax.tick_params(axis='both',direction='in',labelsize=18)
fig.tight_layout()
plt.savefig('vs.png')
plt.savefig('vs.pdf')
plt.show()


fig, ax = plt.subplots()
ax.hist(diff,color='r',edgecolor='black',bins=50,rwidth=5,density=True)
ax.set_xlabel('E$_{DFT}^{int}$ - E$_{ML}^{int}$ (eV)',fontsize=14)
ax.set_ylabel('Normalized frequency',fontsize=14)
ax.tick_params(axis='both',direction='in',labelsize=12)
fig.tight_layout()
#ax.set_xlim(-1.5,1.5)
plt.savefig('interaction.png')
plt.savefig('interaction.pdf')
plt.show()
"""
#-------------------------------------------------------------------------------
#------------------------------------------------------------------------------
training_set_observations = df_train['Ead']
predict_observations_trainingset = df_train['Eml']
std_trainingset = df_train['Std']

test_set_observations = df_test['Ead']
predict_observations_testset = df_test['Eml']
std_testset = df_test['Std']
deltaE_testset = [test_set_observations[i] - predict_observations_testset[i] for i in range(len(predict_observations_testset))]
abs_deltaE = [abs(i) for i in deltaE_testset]
MAE_testset = sum(abs_deltaE)/len(deltaE_testset)

fig, ax = plt.subplots(2,2,figsize=(13,13))
ax[0,0].errorbar(training_set_observations,predict_observations_trainingset,std_trainingset,fmt='bo')
ax[0,0].errorbar(test_set_observations,predict_observations_testset,std_testset,fmt='ro')
ax[0,0].legend(['training','test'],loc='lower right',fontsize=16)
ax[0,0].set_xlabel('G$_{DFT}$ (eV)\n(a)',fontsize=20)
ax[0,0].set_ylabel('G$_{ML}$ (eV)',fontsize=20)
t = np.linspace(-10,15,30)
y = t
ax[0,0].plot(t,y,'--',)
ax[0,0].set_xlim(-2,8)
ax[0,0].set_ylim(-2,8)
ax[0,0].tick_params(axis='both',direction='in',labelsize=18)

ax[0,1].hist(deltaE_testset,color='r',edgecolor='black',bins=50,rwidth=5,density=True)
ax[0,1].set_xlabel('G$_{DFT}$ - G$_{ML}$ (eV)\n(b)',fontsize=20)
ax[0,1].set_ylabel('Normalized frequency',fontsize=20)
ax[0,1].tick_params(axis='both',direction='in',labelsize=18)
ax[0,1].set_xlim(-1.5,1.5)
ax[0,1].text(0.25,1.25,"MAE = %s eV" % round(MAE_testset,3),fontsize=16)
#ax[1].text(left,top,'(a)',fontsize=16,horizontalalignment='left',verticalalignment='bottom',transform=ax1.transAxes)
#ax[1].text(left,top,'(b)',fontsize=16,horizontalalignment='left',verticalalignment='bottom',transform=ax2.transAxes)

# Plot the PDF.
from scipy.stats import norm
mu, std = norm.fit(deltaE_testset)
#xmin, xmax = plt.xlim()
x = np.linspace(-1.5, 1.5, 100)
p = norm.pdf(x, mu, std)
ax[0,1].plot(x, p, 'k', linewidth=1.5)
ax[0,1].annotate('$\sigma$ = %s' % round(std,2),xy=(-0.4,norm.pdf(-0.4,mu,std)),xytext=(-1.25,0.75),arrowprops=dict(facecolor='black',width=0.4,headwidth=6),fontsize=16)  # 6



ax[1,0].scatter(Diff2,Diff1)
t = np.linspace(-2,10,30)
y = t
ax[1,0].plot(t,y,'--',color='k')
ax[1,0].set_xlim(-1.2,6.2)
ax[1,0].set_ylim(-1.2,6.2)
ax[1,0].set_xlabel('G$_{DFT}^{int}$ (eV)\n(c)', fontsize=20)
ax[1,0].set_ylabel('G$_{ML}^{int}$ (eV)', fontsize=20)
ax[1,0].tick_params(axis='both',direction='in',labelsize=18)

ax[1,1].hist(diff,edgecolor='black',bins=50,rwidth=5,density=True)
ax[1,1].set_xlabel('G$_{DFT}^{int}$ - G$_{ML}^{int}$ (eV)\n(d)',fontsize=20)
ax[1,1].set_ylabel('Normalized frequency',fontsize=20)
ax[1,1].tick_params(axis='both',direction='in',labelsize=18)
ax[1,1].set_xlim(-1.5,2.2)
ax[1,1].text(0.25,1.25,"MAE = %s eV" % round(MAE_int,3),fontsize=16)
#ax[1].text(left,top,'(a)',fontsize=16,horizontalalignment='left',verticalalignment='bottom',transform=ax1.transAxes)
#ax[1].text(left,top,'(b)',fontsize=16,horizontalalignment='left',verticalalignment='bottom',transform=ax2.transAxes)

# Plot the PDF.
from scipy.stats import norm
mu, std = norm.fit(diff)
#xmin, xmax = plt.xlim()
x = np.linspace(-1.5, 2.2, 100)
p = norm.pdf(x, mu, std)
ax[1,1].plot(x, p, 'k', linewidth=1.5)
ax[1,1].annotate('$\sigma$ = %s' % round(std,2),xy=(-0.4,norm.pdf(-0.4,mu,std)),xytext=(-1.25,0.75),arrowprops=dict(facecolor='black',width=0.4,headwidth=6),fontsize=16)  # 6
fig.tight_layout()
plt.savefig('ML_DFT.pdf')
plt.savefig('ML_DFT.png')


print ("Mean Eint (DFT): %s " % np.mean(Diff2))
print ("Mean Eint (ML): %s " % np.mean(Diff1))
print ("Mean diff (int): %s " % np.mean(diff))