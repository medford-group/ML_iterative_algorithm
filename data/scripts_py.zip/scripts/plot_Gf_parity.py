#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 15 10:19:27 2020

@author: fuzhu
"""

import pandas as pd

def get_string(df,Num):
    Ads1 = df['Ads1'].tolist()
    Site1 = df['Site1'].tolist()
    Slab = df['Slab'].tolist()
    E_DFT_corr = df['Gf'].tolist()###

    String = []
    E_x_dft = []

    for i in range(Num):
        """ Eads(B) """
        string = Ads1[i] + '_' + Site1[i] + '_' + Slab[i]
        e_dft = E_DFT_corr[i]
        String.append(string)
        E_x_dft.append(e_dft)
    return String,E_x_dft
    
def get_corrections(df,String,E_x_dft):
    ads_strings = ['H','O','OH','H2','O2','H2O','C','CO','CH','CH2','CH3','CH4','N','N2','NO','NH','NH2','NH3']
    Ads2 = df['Ads2'].tolist()
    Site2 = df['Site2'].tolist()
    Slab = df['Slab'].tolist()
    E_corr_dft = []
    for k in range(len(Ads2)):
        ads2 = Ads2[k]
        site2 = Site2[k]
        slab = Slab[k]
        string = ads2 + '_' + site2 + '_' + slab
        #print (string)            
        if ads2 not in ads_strings:
            e_corr = 0
            E_corr_dft.append(e_corr)
        else:
            if string in String:
                idx = String.index(string)
                
                e_corr_dft = E_x_dft[idx]
                E_corr_dft.append(e_corr_dft)
            else:
                e_corr = 100
                E_corr_dft.append(e_corr)
    return E_corr_dft

def Eint(df,Num):
    Gf = df['Gf'].tolist()
    String,E_x_dft = get_string(df,Num)
    E_corr_dft = get_corrections(df,String,E_x_dft)
    Ef = []  ### here the Ef = EA + E(A|B)
    for k in range(len(Gf)):
        ef = Gf[k] + E_corr_dft[k]
        Ef.append(ef)
    Ef = Ef[Num:]
    return Ef

def noEint(df,Num):
    Gf = df['Gf'].tolist()
    Ads1 = df['Ads1'].tolist()
    Site1 = df['Site1'].tolist()
    Ads2 = df['Ads2'].tolist()
    Site2 = df['Site2'].tolist()
    Slab = df['Slab'].tolist()
    S = []
    E = []
    for k in range(Num):
        s = Ads1[k] + '_' + Site1[k] + '_None' + '_' + Slab[k]
        e = Gf[k]
        S.append(s)
        E.append(e)
    Ref = dict(zip(S,E))
    
    Ef = []
    for k in range(Num,len(Gf)):
        
        s1 = Ads1[k] + '_' + Site1[k] + '_None' + '_' + Slab[k]
        s2 = Ads2[k] + '_' + Site2[k] + '_None' + '_' + Slab[k]
        ef = Ref[s1] + Ref[s2]
        Ef.append(ef)
    return Ef
       
df_without = pd.read_csv('formation_ASS_X.csv')
Ef_1 = Eint(df_without,Num=37)
Ef_2 = noEint(df_without,Num=37)

df_with = pd.read_csv('New_formation_ASS_X_bad.csv')
Ef_3 = Eint(df_with,Num=42)
Ef_4 = noEint(df_with,Num=42)

dff_lists = df_with.values.tolist()  ###

#----
str_outliers = []
outliers_3 = []
outliers_4 = []
for k, ef4 in enumerate(Ef_4):
    if ef4 not in Ef_2:
        outliers_3.append(Ef_3[k])
        outliers_4.append(ef4)
        stru = [dff_lists[k][i] for i in range(4)]
        str_outliers.append(stru)
#---

diff = []
for k in range(len(Ef_1)):
    d = Ef_1[k] - Ef_2[k]
    diff.append(d)

import matplotlib.pyplot as plt
import numpy as np
fig, ax = plt.subplots(figsize=(5,5))
ax.scatter(Ef_1,Ef_2,c='r')
ax.scatter(outliers_3,outliers_4,marker='^',c='k',alpha=0.2)
t = np.linspace(-3,15,30)
y = t
ax.plot(t,y,'--',color='k')
ax.set_xlabel('G(A) + G(A|B) (eV)', fontsize=14)
ax.set_ylabel('G(A) + G(B) (eV)', fontsize=14)
ax.set_xlim(-2,13)
ax.set_ylim(-2,13)
ax.tick_params(axis='both',direction='in',labelsize=12)
fig.tight_layout()
plt.savefig('parity_plot.png')
plt.savefig('parity_plot.pdf')
plt.show()

print (len(str_outliers)/len(dff_lists))
#----------------------------------------------------------------------------

"""   
fig, ax = plt.subplots()
ax.hist(diff,color='r',edgecolor='black',bins=80,rwidth=5,density=True)
ax.set_xlabel('Interaction energy (eV)',fontsize=14)
ax.set_ylabel('Normalized frequency',fontsize=14)
ax.tick_params(axis='both',direction='in',labelsize=12)
fig.tight_layout()
#ax.set_xlim(-1.5,1.5)
plt.savefig('interaction.png')
plt.savefig('interaction.pdf')
plt.show()
"""