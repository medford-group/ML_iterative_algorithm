# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 14:08:08 2019

@author: fuzhu
"""

import pandas as pd
old_data = pd.read_csv('New_features_Ead.csv')
columns = old_data.columns.to_numpy()
df = old_data.to_numpy()

old_ass = pd.read_csv('formation_ASS_X.csv')
ass_columns = old_ass.columns.to_numpy()
Old_ASS = old_ass.to_numpy()

New_ASS = []
New_Features_Ead = []
ASS4 = [[A[0],A[1],A[2],A[3]] for A in Old_ASS]
gas = ['N2','O2','H2']
for k, ass in enumerate(ASS4):
    if (ass[0] not in gas) and (ass[2] not in gas):
        New_ASS.append(Old_ASS[k])
        New_Features_Ead.append(df[k])
        
df_ASS = pd.DataFrame(New_ASS,columns=ass_columns)
df_data = pd.DataFrame(New_Features_Ead,columns=columns)

df_ASS.to_csv('New_formation_ASS_X.csv',index=False)
df_data.to_csv('New_New_features_Ead.csv',index=False)

print (df_ASS.shape)
print (df_data.shape)
        