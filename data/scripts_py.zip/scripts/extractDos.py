# -*- coding: utf-8 -*-
"""
Created on Wed Jun 13 09:35:09 2018

@author: fuzhu
"""

# -*- coding: utf-8 -*-
"""
Created on Sat May 26 08:49:49 2018

@author: fuzhu
"""

import numpy as np
import pandas as pd
from scipy.stats import moment
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import pickle
from amp.descriptor.gaussian import Gaussian
from amp.descriptor.zernike import Zernike
from amp.descriptor.bispectrum import Bispectrum
from amp.utilities import hash_images
from itertools import chain
from scipy.ndimage.filters import gaussian_filter1d
from amp.descriptor.gaussian import make_symmetry_functions

class Extract:
    
    """            
    only for the p-orbital of O site and d-orbital for metal site we condisder the gaussian fitting.            
    """    
    elements = ['Ti','O','C','H','N']
    G = make_symmetry_functions(elements=elements,type='G2',etas=np.logspace(np.log10(0.05),np.log10(60),num=4))
    G += make_symmetry_functions(elements=elements,type='G4',etas=[1],zetas=[1,4],gammas=[+1,-1])
    Gs = {'Ti':G,'O':G,'C':G,'H':G,'N':G}
            
    def AtomDOS(self,data=None,n_left=500,n_right=1500,n_component=15,index=None,do_pca=False,atom_fpt=None,
                descriptor='Gaussian',Gs=Gs,cutoff=6.5,nmax=None,jmax=None,reduction=False,dos_moments=True,
                do_moment=False,moment_index=3,moment_n=7,band_width=1):
        doss = []
        smooth_doss = []
        dosp = []
        smooth_dosp = []
        
        dosd = []
        smooth_dosd = []
        atom_fpt = []
        
        moments = []
        moment_scipy = []
        
        if index is None:
            print ("InputErroe: please specify the index of on atom")            
        pickles,trajs,sites = Extract.gen_files(self,data)
        positions = Extract.atom_index(self,index)
        print ('index:', positions)
        #print ('trajs_list:',trajs)
        for k in range(len(pickles)):
#            atoms = trajs[k]
            site = sites[k]
            N = positions[site]
            doc = open(pickles[k])
            data = pickle.load(doc)
            doc.close()
            
            traj = []
            traj.append(trajs[k])
            e_data = data[0]
            dos_e = pd.DataFrame()
            dos_e['E'] = e_data[n_left:n_right]
            dos_e.to_csv('dos_e.csv',index=False)
            if site == 'top_other':
                pdos_up = data[2][N]['s'][0]
                pdos_down = data[2][N]['s'][1]
                s_tot = [(pdos_up[i] + pdos_down[i]) for i in range(len(pdos_up))]
                w = [s_tot[i] for i in range(n_right-n_left)]
                doss.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_doss.append(new_Y)
                
                pdos_up = data[2][N]['p'][0]
                pdos_down = data[2][N]['p'][1]
                tot_p = [(pdos_up[i] + pdos_down[i]) for i in range(len(pdos_up))]
                w = [tot_p[i] for i in range(n_right-n_left)]
                dosp.append(w)
                dosd.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_dosp.append(new_Y)
                smooth_dosd.append(new_Y)
                
                
                if dos_moments is True:
                    # band center and moments 
                    tot_p = new_Y
                    ep = 0
                    p = 0
                    for i in range(len(tot_p)):
                        ep_i = tot_p[i] * e_data[i]
                        ep = ep + ep_i
                        p_i = tot_p[i]
                        p = p_i + p
                        if (i+1) < len(tot_p) and e_data[i] * e_data[i+1] > 0:
                            continue
                        else:
                            break
                    index = i
                    band_center = float(ep)/p
                        
                    e_dos = np.sum([tot_p[i] for i in range(index+1)])
                    mp = []
                    for k in range(1,1+moment_index):
                    # calculate moments
                        dos_moment_n = np.sum([(tot_p[i]*(e_data[i]-band_center)**k) for i in range(index+1)])/e_dos
                        #print (dos_moment_n)
                        mp.append(dos_moment_n)
                        #print ('mp:',len(mp))
                mp[0] = band_center
                md = moment_index * [0,]
                    #print ('md:',len(md))
                m = mp + md
                moments.append(m)
                if atom_fpt is True:
                    fpt = Extract.Atom_Fpt(self,traj,descriptor,Gs,cutoff,nmax,jmax)
                    fp = fpt[N][-1]
                    atom_fpt.append(fp)
                    
                    
                if do_moment is True:
                    md = []
                    for k in range(1,moment_n+1):
                        m = moment(new_Y,moment=k)
                        md.append(m)
                    moment_scipy.append(md)

                
            if site in ['top_metal','top_metal_vac']:
                e_data = data[0]   #   Energy
                pdos_up = data[2][N]['s'][0]
                pdos_down = data[2][N]['s'][1]
                s_tot = [(pdos_up[i] + pdos_down[i]) for i in range(len(pdos_up))]
                w = [s_tot[i] for i in range(n_right-n_left)]
                doss.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_doss.append(new_Y)
                
                pdos_up = data[2][N]['p'][0]
                pdos_down = data[2][N]['p'][1]
                tot_p = [(pdos_up[i] + pdos_down[i]) for i in range(len(pdos_up))]
                w = [tot_p[i] for i in range(n_right-n_left)]
                dosp.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_dosp.append(new_Y)
                
                if dos_moments is True:
                    # band center and moments
                    tot_p = new_Y
                    ep = 0
                    p = 0
                    mp = []
                    for i in range(len(tot_p)):
                        ep_i = tot_p[i] * e_data[i]
                        ep = ep + ep_i
                        p_i = tot_p[i]
                        p = p_i + p
                        if (i+1) < len(tot_p) and e_data[i]*e_data[i+1] > 0:
                            continue
                        else:
                            break
                    index = i
                    band_center = float(ep)/p 
                    
                    for k in range(1,1+moment_index):
                    # calculate moments
                        e_dos = np.sum([tot_p[i] for i in range(index+1)])
                        dos_moment_n = np.sum([tot_p[i]*(e_data[i]-band_center)**k for i in range(index+1)])/e_dos
                        mp.append(dos_moment_n)
                    mp[0] = band_center

                ddos_up = data[2][N]['d'][0]   #
                ddos_down = data[2][N]['d'][1]
                tot_d = [(ddos_up[i] + ddos_down[i]) for i in range(len(ddos_up))]
                w = [tot_d[i] for i in range(n_right-n_left)]
                dosd.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_dosd.append(new_Y)
                
                if dos_moments is True:
                    # band center and moments 
                    tot_d = new_Y
                    ep = 0
                    p = 0
                    md = []
                    for i in range(len(tot_d)):
                        ep_i = tot_d[i] * e_data[i]
                        ep = ep + ep_i
                        p_i = tot_d[i]
                        p = p_i + p
                        if (i+1) < len(tot_d) and e_data[i]*e_data[i+1] > 0:
                            continue
                        else:
                            break
                    index = i
                    band_center = float(ep)/p 
                    
                    for k in range(1,1+moment_index):
                    # calculate moments
                        e_dos = np.sum([tot_d[i] for i in range(index+1)])
                        dos_moment_n = np.sum([(tot_d[i]*(e_data[i]-band_center)**k) for i in range(index+1)])/e_dos
                        md.append(dos_moment_n)
                    md[0] = band_center
                m = mp + md
                moments.append(m)

                if do_moment is True:
                    md = []
                    for k in range(1,moment_n+1):
                        m = moment(new_Y,moment=k)
                        md.append(m)
                    moment_scipy.append(md)
                            
                if atom_fpt is True:
                    fpt = Extract.Atom_Fpt(self,traj,descriptor,Gs,cutoff,nmax,jmax)
                    fp = fpt[N][-1]
                    atom_fpt.append(fp)
                
            if site == 'bridge':
                e_data = data[0]   #   Energy
                ddos_up_0 = data[2][N[0]]['s'][0]
                ddos_down_0 = data[2][N[0]]['s'][1]
                ddos_up_1 = data[2][N[1]]['s'][0]
                ddos_down_1 = data[2][N[1]]['s'][1]
                ddos_0= ddos_up_0 + ddos_down_0
                ddos_1 = ddos_up_1 +ddos_down_1
                s_tot = [(ddos_0[i] + ddos_1[i]) for i in range(len(ddos_0))]
                w = [s_tot[i] for i in range(n_right-n_left)]
                doss.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_doss.append(new_Y)
                
                ddos_up_0 = data[2][N[0]]['p'][0]
                ddos_down_0 = data[2][N[0]]['p'][1]
                ddos_up_1 = data[2][N[1]]['p'][0]
                ddos_down_1 = data[2][N[1]]['p'][1]
                ddos_0= ddos_up_0 + ddos_down_0
                ddos_1 = ddos_up_1 +ddos_down_1
                tot_p = [(ddos_0[i] + ddos_1[i]) for i in range(len(ddos_0))]
                w = [tot_p[i] for i in range(n_right-n_left)]
                dosp.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_dosp.append(new_Y)
                
                if dos_moments is True:
                    # band center and moments
                    tot_p = new_Y
                    ep = 0
                    p = 0
                    mp = []
                    for i in range(len(tot_p)):
                        ep_i = tot_p[i] * e_data[i]
                        ep = ep + ep_i
                        p_i = tot_p[i]
                        p = p_i + p
                        if (i+1) < len(tot_p) and e_data[i]*e_data[i+1] > 0:
                            continue
                        else:
                            break
                    index = i
                    band_center = float(ep)/p 
                    
                    for k in range(1,1+moment_index):
                    # calculate moments
                        e_dos = np.sum([tot_p[i] for i in range(index+1)])
                        dos_moment_n = np.sum([(tot_p[i]*(e_data[i]-band_center)**k) for i in range(index+1)])/e_dos
                        mp.append(dos_moment_n)
                mp[0] = band_center
                
                ddos_up_0 = data[2][N[0]]['d'][0]
                ddos_down_0 = data[2][N[0]]['d'][1]
                ddos_up_1 = data[2][N[1]]['d'][0]
                ddos_down_1 = data[2][N[1]]['d'][1]
                ddos_0= ddos_up_0 + ddos_down_0
                ddos_1 = ddos_up_1 +ddos_down_1
                tot_d = [(ddos_0[i] + ddos_1[i]) for i in range(len(ddos_0))]
                w = [tot_d[i] for i in range(n_right-n_left)]
                dosd.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_dosd.append(new_Y)
                    
                
                if dos_moments is True:
                    # band center and moments
                    tot_d = new_Y
                    ep = 0
                    p = 0
                    md = []
                    for i in range(len(tot_d)):
                        ep_i = tot_d[i] * e_data[i]
                        ep = ep + ep_i
                        p_i = tot_d[i]
                        p = p_i + p
                        if (i+1) < len(tot_d) and e_data[i]*e_data[i+1] > 0:
                            continue
                        else:
                            break
                    index = i
                    band_center = float(ep)/p 
                        
                    for k in range(1,1+moment_index):
                        # calculate moments
                        e_dos = np.sum([tot_d[i] for i in range(index+1)])
                        dos_moment_n = np.sum([(tot_d[i]*(e_data[i]-band_center)**k) for i in range(index+1)])/e_dos
                        md.append(dos_moment_n)
                md[0] = band_center
                m = mp + md
                moments.append(m)
                
                if do_moment is True:  ## only calculate d-DOS
                    md = []
                    for k in range(1,moment_n+1):
                        m = moment(new_Y,moment=k)
                        md.append(m)
                    moment_scipy.append(md)
                    
                
                if atom_fpt is True:
                    fpt = Extract.Atom_Fpt(self,traj,descriptor,Gs,cutoff,nmax,jmax)
                    fp1 = fpt[N[0]][-1]
                    fp2 = fpt[N[1]][-1]
                    fp = [(fp1[i] + fp2[i]) for i in range(len(fp1))]
                    atom_fpt.append(fp)
                
            if site == '3fold':
                e_data = data[0]   #   Energy
                ddos_up_0 = data[2][N[0]]['s'][0]
                ddos_down_0 = data[2][N[0]]['s'][1]
                ddos_up_1 = data[2][N[1]]['s'][0]
                ddos_down_1 = data[2][N[1]]['s'][1]
                ddos_up_2 = data[2][N[2]]['s'][0]
                ddos_down_2 = data[2][N[2]]['s'][1]
                ddos_0 = ddos_up_0 + ddos_down_0
                ddos_1 = ddos_up_1 + ddos_down_1
                ddos_2 = ddos_up_2 + ddos_down_2
                s_tot = [(ddos_0[i] + ddos_1[i] + ddos_2[i]) for i in range(len(ddos_0))]
                w = [s_tot[i] for i in range(n_right-n_left)]
                doss.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_doss.append(new_Y)
                
                ddos_up_0 = data[2][N[0]]['p'][0]
                ddos_down_0 = data[2][N[0]]['p'][1]
                ddos_up_1 = data[2][N[1]]['p'][0]
                ddos_down_1 = data[2][N[1]]['p'][1]
                ddos_up_2 = data[2][N[2]]['p'][0]
                ddos_down_2 = data[2][N[2]]['p'][1]
                ddos_0 = ddos_up_0 + ddos_down_0
                ddos_1 = ddos_up_1 + ddos_down_1
                ddos_2 = ddos_up_2 + ddos_down_2
                tot_p = [(ddos_0[i] + ddos_1[i] + ddos_2[i]) for i in range(len(ddos_0))]
                w = [tot_p[i] for i in range(n_right-n_left)]
                dosp.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_dosp.append(new_Y)
                
                if dos_moments is True:
                    # band center and moments
                    tot_p = new_Y
                    ep = 0
                    p = 0
                    mp = []
                    for i in range(len(tot_p)):
                        ep_i = tot_p[i] * e_data[i]
                        ep = ep + ep_i
                        p_i = tot_p[i]
                        p = p_i + p
                        if (i+1) < len(tot_p) and e_data[i]*e_data[i+1] > 0:
                            continue
                        else:
                            break
                    index = i
                    band_center = float(ep)/p 
                    
                    for k in range(1,1+moment_index):
                    # calculate moments
                        e_dos = np.sum([tot_p[i] for i in range(index+1)])
                        dos_moment_n = np.sum([(tot_p[i]*(e_data[i]-band_center)**k) for i in range(index+1)])/e_dos
                        mp.append(dos_moment_n)
                    mp[0] = band_center
                ddos_up_0 = data[2][N[0]]['d'][0]
                ddos_down_0 = data[2][N[0]]['d'][1]
                ddos_up_1 = data[2][N[1]]['d'][0]
                ddos_down_1 = data[2][N[1]]['d'][1]
                ddos_up_2 = data[2][N[2]]['d'][0]
                ddos_down_2 = data[2][N[2]]['d'][1]
                ddos_0 = ddos_up_0 + ddos_down_0
                ddos_1 = ddos_up_1 + ddos_down_1
                ddos_2 = ddos_up_2 + ddos_down_2
                tot_d = [(ddos_0[i] + ddos_1[i] + ddos_2[i]) for i in range(len(ddos_0))]
                w = [tot_d[i] for i in range(n_right-n_left)]
                dosd.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_dosd.append(new_Y)
                    
                    
                if dos_moments is True:
                    # band center and moments 
                    tot_d = new_Y
                    ep = 0
                    p = 0
                    md = []
                    for i in range(len(tot_d)):
                        ep_i = tot_d[i] * e_data[i]
                        ep = ep + ep_i
                        p_i = tot_d[i]
                        p = p_i + p
                        if (i+1) < len(tot_d) and e_data[i]*e_data[i+1] > 0:
                            continue
                        else:
                            break
                    index = i
                    band_center = float(ep)/p 
                        
                    for k in range(1,1+moment_index):
                    # calculate moments
                        e_dos = np.sum([tot_d[i] for i in range(index+1)])
                        dos_moment_n = np.sum([(tot_d[i]*(e_data[i]-band_center)**k) for i in range(index+1)])/e_dos
                        md.append(dos_moment_n)
                md[0] = band_center
                m = mp + md
                moments.append(m)
                
                if do_moment is True:
                    md = []
                    for k in range(1,moment_n+1):
                        m = moment(new_Y,moment=k)
                        md.append(m)
                    moment_scipy.append(md)
                    
                if atom_fpt is True:
                    fpt = Extract.Atom_Fpt(self,traj,descriptor,Gs,cutoff,nmax,jmax)
                    fp1 = fpt[N[0]][-1]
                    fp2 = fpt[N[1]][-1]
                    fp3 = fpt[N[2]][-1]                    
                    fp = [(fp1[i] + fp2[i] + fp3[i]) for i in range(len(fp1))]
                    atom_fpt.append(fp)
             
            if site == '4fold':
                e_data = data[0]
                ddos_up_0 = data[2][N[0]]['s'][0]
                ddos_down_0 = data[2][N[0]]['s'][1]
                ddos_up_1 = data[2][N[1]]['s'][0]
                ddos_down_1 = data[2][N[1]]['s'][1]
                ddos_up_2 = data[2][N[2]]['s'][0]
                ddos_down_2 = data[2][N[2]]['s'][1]
                ddos_up_3 = data[2][N[3]]['s'][0]
                ddos_down_3 = data[2][N[3]]['s'][1]
                ddos_0 = ddos_up_0 + ddos_down_0
                ddos_1 = ddos_up_1 + ddos_down_1
                ddos_2 = ddos_up_2 + ddos_down_2
                ddos_3 = ddos_up_3 + ddos_down_3
                s_tot = [(ddos_0[i] + ddos_1[i] + ddos_2[i] + ddos_3[i]) for i in range(len(ddos_0))]
                w = [s_tot[i] for i in range(n_right-n_left)]
                doss.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_doss.append(new_Y)
                
                ddos_up_0 = data[2][N[0]]['p'][0]
                ddos_down_0 = data[2][N[0]]['p'][1]
                ddos_up_1 = data[2][N[1]]['p'][0]
                ddos_down_1 = data[2][N[1]]['p'][1]
                ddos_up_2 = data[2][N[2]]['p'][0]
                ddos_down_2 = data[2][N[2]]['p'][1]
                ddos_up_3 = data[2][N[3]]['p'][0]
                ddos_down_3 = data[2][N[3]]['p'][1]
                ddos_0 = ddos_up_0 + ddos_down_0
                ddos_1 = ddos_up_1 + ddos_down_1
                ddos_2 = ddos_up_2 + ddos_down_2
                ddos_3 = ddos_up_3 + ddos_down_3
                tot_p = [(ddos_0[i] + ddos_1[i] + ddos_2[i] + ddos_3[i]) for i in range(len(ddos_0))]
                w = [tot_p[i] for i in range(n_right-n_left)]
                dosp.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_dosp.append(new_Y)
                
                if dos_moments is True:
                    tot_p = new_Y
                    # band center and moments 
                    ep = 0
                    p = 0
                    mp = []
                    for i in range(len(tot_p)):
                        ep_i = tot_p[i] * e_data[i]
                        ep = ep + ep_i
                        p_i = tot_p[i]
                        p = p_i + p
                        if (i+1) < len(tot_p) and e_data[i]*e_data[i+1] > 0:
                            continue
                        else:
                            break
                    index = i
                    band_center = float(ep)/p 
                    
                    for k in range(1,1+moment_index):
                    # calculate moments
                        e_dos = np.sum([tot_p[i] for i in range(index+1)])
                        dos_moment_n = np.sum([(tot_p[i]*(e_data[i]-band_center)**k) for i in range(index+1)])/e_dos
                        mp.append(dos_moment_n)
                
                mp[0] = band_center
                    
                ddos_up_0 = data[2][N[0]]['d'][0]
                ddos_down_0 = data[2][N[0]]['d'][1]
                ddos_up_1 = data[2][N[1]]['d'][0]
                ddos_down_1 = data[2][N[1]]['d'][1]
                ddos_up_2 = data[2][N[2]]['d'][0]
                ddos_down_2 = data[2][N[2]]['d'][1]
                ddos_up_3 = data[2][N[3]]['d'][0]
                ddos_down_3 = data[2][N[3]]['d'][1]
                ddos_0 = ddos_up_0 + ddos_down_0
                ddos_1 = ddos_up_1 + ddos_down_1
                ddos_2 = ddos_up_2 + ddos_down_2
                ddos_3 = ddos_up_3 + ddos_down_3
                tot_d = [(ddos_0[i] + ddos_1[i] + ddos_2[i] + ddos_3[i]) for i in range(len(ddos_0))]
                w = [tot_d[i] for i in range(n_right-n_left)]
                dosd.append(w)
                new_Y = gaussian_filter1d(w,sigma=band_width)
                smooth_dosd.append(new_Y)
                    
                if do_moment is True:
                    md = []
                    for k in range(1,moment_n+1):
                        m = moment(new_Y,moment=k)
                        md.append(m)
                    moment_scipy.append(md)
                    
                if dos_moments is True:
                    tot_d = new_Y
                    # band center and moments 
                    ep = 0
                    p = 0
                    md = []
                    for i in range(len(tot_d)):
                        ep_i = tot_d[i] * e_data[i]
                        ep = ep + ep_i
                        p_i = tot_d[i]
                        p = p_i + p
                        if (i+1) < len(tot_d) and e_data[i]*e_data[i+1] > 0:
                            continue
                        else:
                            break
                    index = i
                    band_center = float(ep)/p 
                    e_dos = np.sum([tot_d[i] for i in range(index+1)])
                    for k in range(1,1+moment_index):
                    # calculate moments
                        dos_moment_n = np.sum([(tot_d[i]*(e_data[i]-band_center)**k) for i in range(index+1)])/e_dos
                        md.append(dos_moment_n)
                md[0] = band_center
                m = mp + md
                moments.append(m)
                if atom_fpt is True:
                    fpt = Extract.Atom_Fpt(self,traj,descriptor,Gs,cutoff,nmax,jmax)
                    fp1 = fpt[N[0]][-1]
                    fp2 = fpt[N[1]][-1]
                    fp3 = fpt[N[2]][-1]                     
                    fp4 = fpt[N[3]][-1]
                    fp = [(fp1[i] + fp2[i] + fp3[i] + fp4[i]) for i in range(len(fp1))]
                    atom_fpt.append(fp)
           
        print ("lenght of doss:", len(smooth_doss))
        print ("length of dosp:",len(smooth_dosp))
        print ("length of dosd:",len(smooth_dosd))
        print ("length of dosd[0]:",len(dosd[0]))
        if atom_fpt is True:
            print ("length of atoms fingerprint:",len(atom_fpt))
            print ("length of atom_fingerprint:",len(atom_fpt[0]))
        if dos_moments is True:
            print ("length of moments:",len(moments))
            print ("length of moments[0]:",len(moments[0]))
        
        column1 = ['fpt_%s' % i for i in range(1,1+(n_right-n_left))]
        sDos_origin = pd.DataFrame(doss,columns=column1)
        sDos_origin.to_csv('sDOS_origin.csv',index=False)
        sDos_smooth = pd.DataFrame(smooth_doss,columns=column1)
        sDos_smooth.to_csv('sDOS_smooth.csv',index=False)
        
        pDos_origin = pd.DataFrame(dosp,columns=column1)
        pDos_origin.to_csv('pDOS_origin.csv',index=False)
        pDos_smooth = pd.DataFrame(smooth_dosp,columns=column1)
        pDos_smooth.to_csv('pDOS_smooth.csv',index=False)

        dDos_origin = pd.DataFrame(dosd,columns=column1)
        dDos_origin.to_csv('dDOS_origin.csv',index=False)
        dDos_smooth = pd.DataFrame(smooth_dosd,columns=column1)
        dDos_smooth.to_csv('dDOS_smooth.csv',index=False)
        
        if dos_moments is True:
            columns = range(1,2*moment_index+1)
            nth_moment = pd.DataFrame(moments,columns=columns)
            nth_moment.to_csv('moments.csv',index=False)

        if do_moment is True:
            columns = ['moment_%s' % k for k in range(1,moment_n+1)]
            nth_moment = pd.DataFrame(moment_scipy,columns=columns)
            nth_moment.to_csv('moment_scipy.csv',index=False)
            
        if atom_fpt is True:
            column4 = ['Sfpt_%s' % i for i in range(1,1+len(atom_fpt[0]))]
            Sfpt = pd.DataFrame(atom_fpt,columns=column4)
            Sfpt.to_csv('Sfpt.csv',index=False)      
        
        if do_pca is True:
            ratio, ratio_sum, dDOS_reduced = Extract.pca(self,dosd,n_component)  ## PCA for the d-projected DOS                  
            dDos = pd.DataFrame(dDOS_reduced)
            Afp = pd.DataFrame(atom_fpt)
            dDOS_FPT = pd.concat([dDos,Afp],axis=1,ignore_index=True)
            np.savetxt('dDOS_FPT.csv',dDOS_FPT,fmt='%.5f')
            
        df = {'doss':doss,'smooth_doss':smooth_doss,
              'dosp':dosp,'smooth_dosp':smooth_dosp,
              'dosd':dosd,'smooth_dosd':smooth_dosd,
              'atom_fpt':atom_fpt, 'moments':moments}
        return df
        
    def Atom_Fpt(self,traj,descriptor,Gs,cutoff,nmax,jmax):
        for t in traj:
            if descriptor == 'Gaussian':
                fingerprint = Gaussian(Gs=Gs,cutoff=cutoff)
            if descriptor == 'Zernike':
                fingerprint = Zernike(nmax=nmax,cutoff=cutoff)
            if descriptor == 'Bispectrum':
                fingerprint = Bispectrum(jmax=jmax,cutoff=cutoff)
            
            images = hash_images(t,ordered=False)
            key = images.keys()
#            print ('key[-1] is: \n',key[-1])
            fingerprint.calculate_fingerprints(images)
            fpt = fingerprint.fingerprints[key[-1]]
        return fpt
        
        
    def gen_files(self,data):
        pickles = []
        trajs = []
        sites = []
        adf = pd.read_csv(data)
        variable_list = adf.columns
        print ("variable_list:", variable_list)
        Ads = adf[variable_list[0]]
        Slab = adf[variable_list[1]]
        Site = adf[variable_list[2]]

        N = len(Ads)       
        for i in range(N):
            slab = Slab[i]
            filename1 = ('dos_' +  '%s' + '.pickle') %  slab
            filename2 = ('%s' + '.traj') % slab
            pickles.append(filename1)
            trajs.append(filename2)
            sites.append(Site[i])
        print ('length of traj files:', len(trajs))
        print ('length of pickle files:', len(pickles))
        print ('length of sites:',len(sites))
        return pickles,trajs,sites
        
    def pca(self,doss,n_component):
        df = doss
#           n = len(df[0])
        N = n_component
        pca = PCA(n_components=N)
#           df = pd.read_csv('adsorbateFingerprint.csv',sep=' ',names=range(n))
        pca.fit(df)
        ratio = (pca.explained_variance_ratio_)
        ratio_sum = np.cumsum(ratio)
        
        if max(ratio_sum) <= 0.95:
            n_component += 1
            pca = PCA(doss,n_component)
            pca.fit(df)
        N = n_component
        DOS_reduced = pca.transform(doss)
        print ("length of DOS_reduced:",len(DOS_reduced))
        np.savetxt('DOS_pca.csv',DOS_reduced,fmt='%.5f')
        
        fig,ax = plt.subplots(figsize=(6,4))
        ax.bar(range(N),ratio[0:N],alpha=0.5,align='center',width=0.6)
        ax.step(range(N),ratio_sum[0:N],where='mid',lw=2)
        plt.xticks(np.arange(0,N))
        plt.xlabel('Principle Components')
        plt.ylabel('Explained Varicance Ratio')
        plt.savefig('adsorbate_pca.png')
        plt.legend(['DOS_PCA'],loc='best')
        plt.tight_layout()
        return ratio, ratio_sum, DOS_reduced
        
        
    def atom_index(self,index):
        """
        # index should be like this dictionary
        index = {
        'top_metal':num1,
        'top_metal_vac':num2,
        'top_other':num2,
        'bridge':[num1,num2],
        '3fold':[num1,num2,num3],
        '4fold':[num1,num2,num3,num4]}
        """
        positions = index
        return positions
        
    def ads_energy(self,data):
        adf = pd.read_csv(data)
        variable_list = adf.columns
        energy = adf[variable_list[-1]]
        return energy

