# -*- coding: utf-8 -*-
"""
Created on Tue Aug  7 15:36:05 2018

@author: fuzhu
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF
import random

"""
Iteration: This script randomly extracts max(std) or max(deltaE) from test set to training set
Iteration_max: This script extracts max(std) or max(deltaE) from test set to training set

"""

class iteration():
    
    def analyze_data(self,origin_data,new_data,Num,alpha=0.2,max_cycle=500,std=False,random_state=False,threshold_std=0.7,threshold_dE=1,kk=1):
        
        #new_data is from feature construction
        # Num is the number of low coverage configurations
        
        
        # this output the final configurations!
        df_origin = pd.read_csv(origin_data)
        df_origin = df_origin.dropna(axis=0,how='any')
        print (df_origin.shape)
        col_var = df_origin.columns.get_values().tolist()  # 
        col_var.remove(col_var[-1])
        print ('columns_name:',col_var)
        print ("origin_data.shape:",df_origin.shape)
        training_set_AdsSlabSite = df_origin.iloc[:Num,:-1].values.tolist()
        #training_set_observations = df_origin.iloc[:Num,-1].tolist()
        test_set_AdsSlabSite = df_origin.iloc[Num:,:-1].values.tolist()
        #test_set_observations = df_origin.iloc[Num:,-1].tolist()
        
        # Initialize the parameters:
        df = pd.read_csv(new_data)
        print ("new_data.shape:",df.shape)
        X = df.values[:,:-1]  # we predict energy finally
        index_of_samples = range(len(df))
        training_set_variables = df.iloc[:Num,:-1].values.tolist()
        training_set_observations = df.iloc[:Num,-1].tolist()
        test_set_variables = df.iloc[Num:,:-1].values.tolist()
        test_set_observations = df.iloc[Num:,-1].tolist()
        MaxStd_testset=5
        MaxdE_testset=5
        print ("The number of initial training/test set and total samples are [%s, %s, %s]" % (len(training_set_observations),len(test_set_observations),len(index_of_samples)))
                                                       
        for i in range(max_cycle):
            run_std = std
            if std is True:
                if MaxStd_testset > threshold_std:
                    management = iteration.gpr(self,X,training_set_variables,training_set_observations,alpha,test_set_variables,test_set_observations,run_std,
                                               random_state,threshold_std,threshold_dE,training_set_AdsSlabSite,test_set_AdsSlabSite,kk)
                    MaxStd_testset = management['MaxStd_testset']
                    std_index = management['std_index']
                    MaxdE_testset = management['MaxdE_testset']
                    training_set_AdsSlabSite = management['training_set_AdsSlabSite']
                    test_set_AdsSlabSite = management['test_set_AdsSlabSite']
                    print ("This is %s_th iteration, MaxdE of test_set is ** %s eV **" % (i,round(MaxStd_testset,3)))
                    print ('')
                    
                    
                    elements = [test_set_variables[k] for k in std_index]
                    for elem in elements:
                        indx = test_set_variables.index(elem)
                        
                        ads1 = test_set_AdsSlabSite[indx][0]
                        site1 = test_set_AdsSlabSite[indx][1]
                        ads2 = test_set_AdsSlabSite[indx][2]
                        site2 = test_set_AdsSlabSite[indx][3]                        
                        
                        training_set_variables.append(elem)
                        training_set_observations.append(test_set_observations[indx])
                        test_set_variables.remove(elem)
                        test_set_observations.remove(test_set_observations[indx])
                        
                        training_set_AdsSlabSite.append(test_set_AdsSlabSite[indx])
                        test_set_AdsSlabSite.remove(test_set_AdsSlabSite[indx])
                        
                        for list_i in test_set_AdsSlabSite:
                            if (ads2 == list_i[0]) and (site2 == list_i[1]) and (ads1 == list_i[2]) and (site1 == list_i[3]):    
                                ind_same_str = test_set_AdsSlabSite.index(list_i)
                                
                                training_set_AdsSlabSite.append(test_set_AdsSlabSite[ind_same_str])
                                random_testset_variables = test_set_AdsSlabSite[ind_same_str]
                                test_set_AdsSlabSite.remove(random_testset_variables)
                                
                                
                                training_set_variables.append(test_set_variables[ind_same_str])
                                training_set_observations.append(test_set_observations[ind_same_str])
                                
                                random_testset_variables = test_set_variables[ind_same_str]
                                random_testset_observations = test_set_observations[ind_same_str]
                                test_set_variables.remove(random_testset_variables)
                                test_set_observations.remove(random_testset_observations)   
                            else:
                                pass                    
                    
                else:
                    NumOf_dft = len(training_set_variables)
                    print (" # # # # # # # # Iterations Have Convereged # # # # # # # # #")
                    print ("########### Summary ##########:")
                    print ("The number of samples = %s" % len(index_of_samples))
                    print ("The number of converged samples = %s" % len(training_set_variables))
                    print ("After %s times iteration, MaxdE of test_set is ** %s eV **" % (i,round(MaxdE_testset,3)))
                    print ("After %s times iteration, MaxStd of test_set is ** %s eV **" % (i,round(MaxStd_testset,3)))
                                        
                    iteration.save_AdsSlabSite(self,col_var,management)
                    iteration.save_predicted_values(self,origin_data,management)
                    MAE_trainingset, MAE_testset = iteration.plot_deltaE(self,management)
                    iteration.plot_DFT_ML(self,management)
                    iteration.plot_emerge(self,management)
                    iteration.find_outlier(self,df,management,threshold_dE)
                    break

            else: 
                if MaxdE_testset > threshold_dE:
                    management = iteration.gpr(self,X,training_set_variables,training_set_observations,alpha,test_set_variables,test_set_observations,run_std,
                                               random_state,threshold_std,threshold_dE,training_set_AdsSlabSite,test_set_AdsSlabSite,kk)
                    MaxdE_testset = management['MaxdE_testset']
                    MaxStd_testset = management['MaxStd_testset']
                    deltaE_index = management['deltaE_index']
                    training_set_AdsSlabSite = management['training_set_AdsSlabSite']
                    test_set_AdsSlabSite = management['test_set_AdsSlabSite']

                    print ("This is %s_th iteration, MaxdE of test_set is ** %s eV **" % (i,round(MaxdE_testset,3)))
                    print ('')

                    elements = [test_set_variables[k] for k in deltaE_index]
                    for elem in elements:
                        indx = test_set_variables.index(elem)
                        
                        ads1 = test_set_AdsSlabSite[indx][0]
                        site1 = test_set_AdsSlabSite[indx][1]
                        ads2 = test_set_AdsSlabSite[indx][2]
                        site2 = test_set_AdsSlabSite[indx][3]                        
                        
                        training_set_variables.append(elem)
                        training_set_observations.append(test_set_observations[indx])
                        test_set_variables.remove(elem)
                        test_set_observations.remove(test_set_observations[indx])
                        
                        training_set_AdsSlabSite.append(test_set_AdsSlabSite[indx])
                        test_set_AdsSlabSite.remove(test_set_AdsSlabSite[indx])
                        
                        for list_i in test_set_AdsSlabSite:
                            if (ads2 == list_i[0]) and (site2 == list_i[1]) and (ads1 == list_i[2]) and (site1 == list_i[3]):    
                                ind_same_str = test_set_AdsSlabSite.index(list_i)
                                
                                training_set_AdsSlabSite.append(test_set_AdsSlabSite[ind_same_str])
                                random_testset_variables = test_set_AdsSlabSite[ind_same_str]
                                test_set_AdsSlabSite.remove(random_testset_variables)
                                
                                
                                training_set_variables.append(test_set_variables[ind_same_str])
                                training_set_observations.append(test_set_observations[ind_same_str])
                                
                                random_testset_variables = test_set_variables[ind_same_str]
                                random_testset_observations = test_set_observations[ind_same_str]
                                test_set_variables.remove(random_testset_variables)
                                test_set_observations.remove(random_testset_observations)   
                            else:
                                pass 
                        
                else:
                    NumOf_dft = len(training_set_variables)
                    print ("# # # # # # # # # # Iterations have convereged # # # # # # # # # #")
                    print ("## ## ## ## ## ## Summary ## ## ## ## ## ##")
                    print ("The number of samples = %s" % len(index_of_samples))
                    print ("The number of converged samples = %s" % len(training_set_observations))
                    print ("After %s times iteration, MaxdE of test_set is ** %s **" % (i,round(MaxdE_testset,3)))
                    print ("After %s times iteration, MaxStd of test_set is ** %s eV **" % (i,round(MaxStd_testset,3)))
                    
                    iteration.save_AdsSlabSite(self,col_var,management)
                    iteration.save_predicted_values(self,origin_data,management)
                    MAE_trainingset, MAE_testset = iteration.plot_deltaE(self,management)
                    iteration.plot_DFT_ML(self,management)
                    iteration.plot_emerge(self,management)
                    iteration.find_outlier(self,df,management,threshold_dE)
                    break
        
        return i, NumOf_dft, MAE_testset
        
        
    def gpr(self,X,training_set_variables,training_set_observations,alpha,test_set_variables,test_set_observations,run_std,random_state,threshold_std,threshold_dE,training_set_AdsSlabSite,test_set_AdsSlabSite,kk):
        kernel_rbf = 1 * RBF(length_scale=1,length_scale_bounds=(0.01,500))
        model = GaussianProcessRegressor(kernel=kernel_rbf,alpha=alpha,n_restarts_optimizer=5)  #   alpha = 0.2
        model.fit(training_set_variables,training_set_observations)
        
        # just checking the training set
        predict_observations_trainingset, std_trainingset = model.predict(training_set_variables,return_std=True)
        deltaE_trainingset = [training_set_observations[i] - predict_observations_trainingset[i] for i in range(len(predict_observations_trainingset))]
        print ("maximum and miximum values for the E_DFT - E_ML on training set = (%s, %s)" % (round(max(deltaE_trainingset),3),round(min(deltaE_trainingset),3)))

        predict_observations_testset, std_testset = model.predict(test_set_variables,return_std=True)
        deltaE_testset = [test_set_observations[i] - predict_observations_testset[i] for i in range(len(predict_observations_testset))]
        print ("maximum and miximum values for the E_DFT - E_ML on test set = (%s, %s)" % (round(max(deltaE_testset),3),round(min(deltaE_testset),3)))
        print ("length of (trainingset, testset) = (%s, %s)" % (len(training_set_observations),len(test_set_observations)))
        
        Y_predicted, std = model.predict(X,return_std=True)

        # consider error bar (Uncertainty)
        if run_std is True:
            abs_deltaE = [abs(i) for i in deltaE_testset]
            MaxdE_testset = max(abs_deltaE)
            # first method: large uncertainty
            MaxStd_testset = max(std_testset)
            std_index = []
            if MaxStd_testset > threshold_std:
                if random_state is True:
                    std = [std_i for std_i in list(set(std_testset)) if std_i > threshold_std]
                    if len(std) > 10:
                        k = kk
                        list_std = random.sample(population=std,k=k)
                    else:
                        k = 1
                        list_std = random.sample(population=std,k=k)
                else:
                    std = sorted([std_i for std_i in list(set(std_testset)) if std_i > threshold_std])                
                    if len(std) > 10:
                        k = kk
                        list_std = std[-k:]
                    else:
                        k = 1
                        list_std = std[-k:]
                for std_i in list_std:
                    index_i = list(std_testset).index(std_i)
                    std_index.append(index_i)
                management = {'MaxStd_testset':MaxStd_testset, 'std_index':std_index, 'MaxdE_testset':MaxdE_testset,'test_set_observations':test_set_observations,
                              'deltaE_trainingset':deltaE_trainingset, 'deltaE_testset':deltaE_testset, 'training_set_observations':training_set_observations,
                              'predict_observations_trainingset':predict_observations_trainingset,'test_set_observations':test_set_observations,
                              'predict_observations_testset':predict_observations_testset,'std_trainingset':std_trainingset,'std_testset':std_testset,
                              'test_set_AdsSlabSite':test_set_AdsSlabSite,'training_set_AdsSlabSite':training_set_AdsSlabSite,'Y_predicted':Y_predicted,'std':std}
            else:
                management = {'MaxStd_testset':MaxStd_testset, 'std_index':std_index, 'MaxdE_testset':MaxdE_testset,'test_set_observations':test_set_observations,
                              'deltaE_trainingset':deltaE_trainingset, 'deltaE_testset':deltaE_testset, 'training_set_observations':training_set_observations,
                              'predict_observations_trainingset':predict_observations_trainingset,'test_set_observations':test_set_observations,
                              'predict_observations_testset':predict_observations_testset,'std_trainingset':std_trainingset,'std_testset':std_testset,
                              'test_set_AdsSlabSite':test_set_AdsSlabSite,'training_set_AdsSlabSite':training_set_AdsSlabSite,'Y_predicted':Y_predicted,'std':std}                
         
           
        # consider energy difference
        else:
            # second method: large energy difference between DFT and ML energy
            MaxStd_testset = max(std_testset)
            abs_deltaE = [abs(i) for i in deltaE_testset]
            MaxdE_testset = max(abs_deltaE)
            deltaE_index = []
            if MaxdE_testset > threshold_dE:
                if random_state is True:
                    deltaE = [i for i in list(set(deltaE_testset)) if abs(i) > threshold_dE]
                    if len(deltaE) > 10:
                        k = kk
                        list_dE = random.sample(population=deltaE,k=k)
                    else:
                        k = 1
                        list_dE = random.sample(population=deltaE,k=k)
                else:
                    deltaE = sorted([i for i in list(set(deltaE_testset)) if abs(i) > threshold_dE],key=abs)
                    if len(deltaE) > 10:
                        k = kk
                        list_dE = deltaE[-k:]
                    else:
                        k = 1
                        list_dE = deltaE[-k:]   
                for de in list_dE:
                    index_i = deltaE_testset.index(de)
                    deltaE_index.append(index_i)
            
                management = {'MaxStd_testset':MaxStd_testset,'MaxdE_testset':MaxdE_testset,'deltaE_index':deltaE_index,'deltaE_trainingset':deltaE_trainingset,
                              'deltaE_testset':deltaE_testset, 'training_set_observations':training_set_observations,
                              'predict_observations_trainingset':predict_observations_trainingset,'test_set_observations':test_set_observations,'test_set_variables':test_set_variables,
                              'predict_observations_testset':predict_observations_testset,'std_trainingset':std_trainingset,'std_testset':std_testset,
                              'test_set_AdsSlabSite':test_set_AdsSlabSite,'training_set_AdsSlabSite':training_set_AdsSlabSite,'Y_predicted':Y_predicted,'std':std}

            else:
                management = {'MaxStd_testset':MaxStd_testset,'MaxdE_testset':MaxdE_testset,'deltaE_index':deltaE_index,'deltaE_trainingset':deltaE_trainingset,
                              'deltaE_testset':deltaE_testset, 'training_set_observations':training_set_observations,
                              'predict_observations_trainingset':predict_observations_trainingset,'test_set_observations':test_set_observations,'test_set_variables':test_set_variables,
                              'predict_observations_testset':predict_observations_testset,'std_trainingset':std_trainingset,'std_testset':std_testset,
                              'test_set_AdsSlabSite':test_set_AdsSlabSite,'training_set_AdsSlabSite':training_set_AdsSlabSite,'Y_predicted':Y_predicted,'std':std}
                                
        return management
        
    def plot_deltaE(self,management):
        # Mean Absolute Error
        deltaE_trainingset = management['deltaE_trainingset']
        abs_deltaE = [abs(i) for i in deltaE_trainingset]
        MAE_trainingset = sum(abs_deltaE)/len(deltaE_trainingset)
        print ("The Mean Absolute Error of Training Set is = %s !" % round(MAE_trainingset,3))
        fig,ax = plt.subplots()
        ax.hist(deltaE_trainingset,color='b',edgecolor='black',bins=20,rwidth=5,density=True)
        ax.set_xlabel('E$_{DFT}$ - E$_{ML}$ (eV)',fontsize=16)
        ax.set_ylabel('Normalized frequency',fontsize=16)
        ax.tick_params(axis='both',direction='in',labelsize=14)
        ax.set_xlim(-1.5,1.5)
        ax.text(0.4,1.5,"MAE = %s eV" % round(MAE_trainingset,3),fontsize=14)
        fig.tight_layout()
        plt.savefig('dE_trainingset.pdf')
        plt.savefig('dE_trainingset.png')
        #plt.show()
        deltaE_testset = management['deltaE_testset']
        abs_deltaE = [abs(i) for i in deltaE_testset]
        MAE_testset = sum(abs_deltaE)/len(deltaE_testset)
        print ("The Mean Absolute Error of Test Set is = %s !" % round(MAE_testset,3))
        
        fig,ax = plt.subplots()
        ax.hist(deltaE_testset,color='r',edgecolor='black',bins=20,rwidth=5,density=True)
        ax.set_xlabel('E$_{DFT}$ - E$_{ML}$ (eV)',fontsize=16)
        ax.set_ylabel('Normalized frequency',fontsize=16)
        ax.tick_params(axis='both',direction='in',labelsize=14)
        ax.set_xlim(-1.5,1.5)
        ax.text(0.4,0.6,"MAE = %s eV" % round(MAE_testset,3),fontsize=14)
        fig.tight_layout()
        plt.savefig('dE_testset.pdf')
        plt.savefig('dE_testset.png')
        #plt.show()
        return MAE_trainingset, MAE_testset
        
    def plot_DFT_ML(self,management):
        # DFT and ML energies
        training_set_observations = management['training_set_observations']
        predict_observations_trainingset = management['predict_observations_trainingset']
        test_set_observations = management['test_set_observations']
        predict_observations_testset = management['predict_observations_testset']
        std_trainingset = management['std_trainingset']
        std_testset = management['std_testset']
        Mean_Std_training = round(np.mean(std_trainingset),3)
        Mean_Std_test = round(np.mean(std_testset),3)
        print ("The Mean_Std for trainingset is = %s !" % Mean_Std_training)
        print ("The Mean_Std for testset is = %s !" % Mean_Std_test)
        fig,ax = plt.subplots()
        ax.errorbar(training_set_observations,predict_observations_trainingset,std_trainingset,fmt='bo')
        ax.errorbar(test_set_observations,predict_observations_testset,std_testset,fmt='ro')
        ax.legend(['train','test'],loc='best',fontsize=14)
        ax.set_xlabel('E$_{DFT}$ (eV)',fontsize=16)
        ax.set_ylabel('E$_{ML}$ (eV)',fontsize=16)
        t = np.linspace(-3,8.5,30)
        y = t
        ax.plot(t,y,'--',)
        #plt.xlim(-2.5,8.5)
        #plt.ylim(-2.5,8.5)
        ax.set_xlim(-2,8)
        ax.set_ylim(-2,8)
        ax.tick_params(axis='both',direction='in',labelsize=14)
        fig.tight_layout()
        plt.savefig('gpr.pdf')
        plt.savefig('gpr.png')
        #plt.show()
        Number_of_trainingset = len(training_set_observations)
        Number_of_testset = len(test_set_observations)
        return Number_of_trainingset, Number_of_testset
        
    def save_AdsSlabSite(self,col_var,management):
        training_set_observations = management['training_set_observations']
        test_set_observations = management['test_set_observations']
        training_set_AdsSlabSite = management['training_set_AdsSlabSite']
        test_set_AdsSlabSite = management['test_set_AdsSlabSite']
        
        #col_var = ['Ads','Slab','Site']
        AdsSlabSite_trainingset = pd.DataFrame(training_set_AdsSlabSite,columns=col_var)
        AdsSlabSite_trainingset.insert(loc=len(col_var),column='Ead',value=training_set_observations)
        AdsSlabSite_trainingset.to_csv('best_trainingset.csv',index=False)
        
        AdsSlabSite_testset = pd.DataFrame(test_set_AdsSlabSite,columns=col_var)
        AdsSlabSite_testset.insert(loc=len(col_var),column='Ead',value=test_set_observations)
        AdsSlabSite_testset.to_csv('best_testset.csv',index=False)
        Number_of_training_set_AdsSlabSite = len(training_set_AdsSlabSite) 
        Number_of_test_set_AdsSlabSite = len(test_set_AdsSlabSite)
        return Number_of_training_set_AdsSlabSite, Number_of_test_set_AdsSlabSite
        
    def save_predicted_values(self,origin_data,management):
        E_ml = management['Y_predicted']
        Std = management['std']
        dff = pd.read_csv(origin_data)
        dff = dff.dropna(axis=0,how='any')
        columns = dff.columns
        dff.insert(loc=len(columns),column='energyML',value=E_ml)
        columns = dff.columns
        dff.insert(loc=len(columns),column='Std',value=Std)
        dff.to_csv('Analysis_data.csv',index=False)

    def find_outlier(self,df,management,threshold_dE):
        Y_ml = management['Y_predicted']
        Y_dft = df[df.columns[-1]]
        delta_Y = [abs(Y_dft[i] - Y_ml[i]) for i in range(len(Y_dft))]
        Idx = []
        for value in delta_Y:
            if value >= threshold_dE:
                idx = delta_Y.index(value)
                Idx.append(idx)
                print ('Check structures:')
                print ("(index, E_dft, delta_E):", tuple([idx,Y_dft[idx],value]))  #  (tuple([idx,df.iloc[idx,:].tolist()]))
            else:
                pass
        print ("Length of Outliers:", len(Idx))
        return Idx        

    def plot_emerge(self,management):
        # DFT and ML energies
        training_set_observations = management['training_set_observations']
        predict_observations_trainingset = management['predict_observations_trainingset']
        test_set_observations = management['test_set_observations']
        predict_observations_testset = management['predict_observations_testset']
        std_trainingset = management['std_trainingset']
        std_testset = management['std_testset']
        Mean_Std_training = round(np.mean(std_trainingset),3)
        Mean_Std_test = round(np.mean(std_testset),3)
        print ("The Mean_Std for trainingset is = %s !" % Mean_Std_training)
        print ("The Mean_Std for testset is = %s !" % Mean_Std_test)
        
        deltaE_testset = management['deltaE_testset']
        abs_deltaE = [abs(i) for i in deltaE_testset]
        MAE_testset = sum(abs_deltaE)/len(deltaE_testset)
        print ("The Mean Absolute Error of Test Set is = %s !" % round(MAE_testset,3))
        
        fig = plt.figure(tight_layout=True,figsize=(6,8))
        left = 0.025
        top = 0.9
        ax1 = plt.subplot(211)
        ax1.errorbar(training_set_observations,predict_observations_trainingset,std_trainingset,fmt='bo')
        ax1.errorbar(test_set_observations,predict_observations_testset,std_testset,fmt='ro')
        ax1.legend(['train','test'],loc='lower right',fontsize=14)
        ax1.set_xlabel('E$_{DFT}$ (eV)',fontsize=16)
        ax1.set_ylabel('E$_{ML}$ (eV)',fontsize=16)
        t = np.linspace(-3,8.5,30)
        y = t
        ax1.plot(t,y,'--',)
        #ax1.set_xlim(-2.5,8.5)
        #ax1.set_ylim(-2.5,8.5)
        plt.xlim(-2,8)
        plt.ylim(-2,8)
        ax1.tick_params(axis='both',direction='in',labelsize=14)

        ax2 = plt.subplot(212)
        ax2.hist(deltaE_testset,color='r',edgecolor='black',bins=20,rwidth=5,density=True)
        ax2.set_xlabel('E$_{DFT}$ - E$_{ML}$ (eV)',fontsize=16)
        ax2.set_ylabel('Normalized frequency',fontsize=16)
        ax2.tick_params(axis='both',direction='in',labelsize=14)
        ax2.set_xlim(-1.5,1.5)
        ax2.text(0.4,0.6,"MAE = %s eV" % round(MAE_testset,3),fontsize=14)
        ax1.text(left,top,'(a)',fontsize=14,horizontalalignment='left',verticalalignment='bottom',transform=ax1.transAxes)
        ax2.text(left,top,'(b)',fontsize=14,horizontalalignment='left',verticalalignment='bottom',transform=ax2.transAxes)
        plt.savefig('Figure.pdf')
        plt.savefig('Figure.png')
